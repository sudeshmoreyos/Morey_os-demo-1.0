#ifndef CONFIG_H
#define CONFIG_H

#define COMPILER AVR_GCC
#define SERIAL_ENABLE

#endif

